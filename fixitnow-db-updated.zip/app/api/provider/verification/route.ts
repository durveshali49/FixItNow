import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { supabaseAdmin } from '@/lib/admin/auth'

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    
    // Get the current user
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const { documents, bio } = await request.json()

    if (!documents || !Array.isArray(documents) || documents.length === 0) {
      return NextResponse.json(
        { error: 'At least one document is required' },
        { status: 400 }
      )
    }

    if (!bio || !bio.trim()) {
      return NextResponse.json(
        { error: 'Professional bio is required' },
        { status: 400 }
      )
    }

    // Check if user is a service provider
    const { data: userProfile } = await supabase
      .from('users')
      .select('role')
      .eq('id', user.id)
      .single()

    if (!userProfile || userProfile.role !== 'service_provider') {
      return NextResponse.json(
        { error: 'Only service providers can submit verification requests' },
        { status: 403 }
      )
    }

    // Insert or update verification request using admin client (bypasses RLS)
    const { data, error } = await supabaseAdmin
      .from('service_provider_verifications')
      .upsert({
        service_provider_id: user.id,
        status: 'pending',
        documents_submitted: documents,
        verification_notes: bio,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .select()

    if (error) {
      console.error('Database error:', error)
      return NextResponse.json(
        { error: 'Failed to submit verification request' },
        { status: 500 }
      )
    }

    return NextResponse.json({
      success: true,
      message: 'Verification request submitted successfully',
      data
    })

  } catch (error: any) {
    console.error('Verification submission error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    
    // Get the current user
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }

    // Get existing verification for this user using admin client
    const { data: verification, error } = await supabaseAdmin
      .from('service_provider_verifications')
      .select('*')
      .eq('service_provider_id', user.id)
      .single()

    if (error && error.code !== 'PGRST116') { // PGRST116 is "no rows returned"
      console.error('Database error:', error)
      return NextResponse.json(
        { error: 'Failed to fetch verification status' },
        { status: 500 }
      )
    }

    return NextResponse.json({
      success: true,
      data: verification || null
    })

  } catch (error: any) {
    console.error('Verification fetch error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}